import org.cloudbus.cloudsim.*;
import java.util.*;

public class LoadBalancingAlgorithm {
    public static void main(String[] args) {
        int numUsers = 100;
        int numVms = 10;
        int cloudletsPerUser = 5;
        int brokerId = 0;
        String vmType = "Small";

        try {
            // Initialize CloudSim
            CloudSim.init(numUsers, Calendar.getInstance(), false);

            // Create Datacenters and VMs
            Datacenter datacenter = createDatacenter();
            List<Vm> vmList = createVmList(numVms, vmType);

            // Create Cloudlets for each user
            List<Cloudlet> cloudletList = new ArrayList<Cloudlet>();
            for(int i = 0; i < numUsers; i++) {
                List<Cloudlet> userCloudletList = createUserCloudletList(cloudletsPerUser);
                cloudletList.addAll(userCloudletList);
            }

            // Create Broker and submit Cloudlets
            DatacenterBroker broker = createBroker(brokerId);
            broker.submitVmList(vmList);
            broker.submitCloudletList(cloudletList);

            // Run Simulation
            CloudSim.startSimulation();

            // Print Results
            List<Cloudlet> resultList = broker.getCloudletReceivedList();
            CloudSim.stopSimulation();
            printCloudletList(resultList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Datacenter createDatacenter() {
        // Create Datacenter Characteristics
        String architecture = "x86";
        String os = "Linux";
        String vmm = "Xen";
        double time_zone = 10.0;
        double cost = 3.0;
        double costPerMem = 0.05;
        double costPerStorage = 0.001;
        double costPerBw = 0.0;
        LinkedList<Storage> storageList = new LinkedList<Storage>();

        // Create Datacenter
        Datacenter datacenter = null;
        try {
            datacenter = new Datacenter("Datacenter", createCharacteristics(architecture, os, vmm, time_zone, cost, costPerMem, costPerStorage, costPerBw), new VmAllocationPolicySimple(createVmList(100, "Small")), storageList, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return datacenter;
    }

    private static DatacenterCharacteristics createCharacteristics(String architecture, String os, String vmm, double time_zone, double cost, double costPerMem, double costPerStorage, double costPerBw) {
        DatacenterCharacteristics characteristics = new DatacenterCharacteristics(architecture, os, vmm, new LinkedList<Pe>(), time_zone, cost, costPerMem, costPerStorage, costPerBw);
        return characteristics;
    }

    private static List<Vm> createVmList(int numVms, String vmType) {
        List<Vm> vmList = new ArrayList<Vm>();
        int mips = 1000;
        long size = 10000;
        int ram = 512;
        long bw = 1000;
        String vmm = "Xen";
        for(int i = 0; i < numVms; i++) {
            Vm vm = new Vm(i, brokerId, mips, 1, ram, bw, size, vmm, new CloudletSchedulerSpaceShared());
            vm.setUserId(brokerId);
            vmList.add(vm);
        }
       
